package com.example.pok.week7_0;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;

public class EditUpadateActivity extends AppCompatActivity {
    private EditText name_Edit2,tel_Edit2,e_mail_Edit2;
    private Button edit3,update3,getImg3,getCamera3;
    private ImageView imageView3;
    Integer _id3;
    private Contact contactEdit;
    byte[] photo ;
    String nameEdit,telEdit,e_mailEdit;
    Bitmap bp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_upadate);
        final DatabaseHandler db3 = new DatabaseHandler(this);

        name_Edit2 = (EditText) findViewById(R.id.editTextND1);
        tel_Edit2 = (EditText) findViewById(R.id.editTextTD1);
        e_mail_Edit2 = (EditText) findViewById(R.id.editTextED1);
        edit3 =(Button) findViewById(R.id.button_edit3);
        update3 = (Button) findViewById(R.id.button_update3);
        getImg3 = (Button) findViewById(R.id.button_getimg3);
        getCamera3 = (Button) findViewById(R.id.button_getcamera3);
        imageView3= (ImageView) findViewById(R.id.imageEdit3);

        Bundle bundle1  = getIntent().getExtras();
        _id3 = bundle1.getInt("id");
        contactEdit = db3.getContact(_id3.toString());
        name_Edit2.setText(contactEdit._name);
        tel_Edit2.setText(contactEdit._phone_number);
        e_mail_Edit2.setText(contactEdit._e_mail);
        bp = convertToBitmap3(contactEdit._img);
        imageView3.setImageBitmap(convertToBitmap3(contactEdit._img));
       // AlertDialog.Builder dialog = new AlertDialog.Builder(EditUpadateActivity.this);
       // final AlertDialog.Builder dialog3 = new AlertDialog.Builder(EditUpadateActivity.this);


        edit3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder dialog3 = new AlertDialog.Builder(EditUpadateActivity.this);
                dialog3.setTitle("EditProfile");
                dialog3.setMessage("คุณกำลังแก้ไขข้อมูลถ้าแก้ไขเรียบร้อยให้กด Update");
                dialog3.setPositiveButton("ตกลง", new AlertDialog.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i3) {
                        dialogInterface.cancel();
                    }
                });
                dialog3.show();

            }
        });
        update3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //nameEdit =name_Edit2.getText().toString();
                //telEdit = tel_Edit2.getText().toString();
                //e_mailEdit = e_mail_Edit2.getText().toString();
                AlertDialog.Builder dialog5 = new AlertDialog.Builder(EditUpadateActivity.this);
                dialog5.setTitle("EditProfile");
                dialog5.setMessage("คุณยืนยันแก้ไขข้อมูลหรือไม่");
                dialog5.setPositiveButton("ตกลง", new AlertDialog.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i3) {
                        photo = profileImage(bp);
                        nameEdit =name_Edit2.getText().toString();
                        telEdit = tel_Edit2.getText().toString();
                        e_mailEdit = e_mail_Edit2.getText().toString();

                        Intent mainActivity3 = new Intent(EditUpadateActivity.this,MainActivity.class);
                        Toast.makeText(getApplicationContext(), "status1= "+nameEdit+" "+ telEdit+" "+e_mailEdit, Toast.LENGTH_SHORT).show();
                        db3.updateContact(new Contact(_id3,nameEdit,telEdit,e_mailEdit,photo));
                        startActivity(mainActivity3);
                        onDestroy();
                        finish();
                    }
                });
                dialog5.setNegativeButton("ยกเลิก", new AlertDialog.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.cancel();
                    }
                });
                dialog5.show();

            }
        });
        getImg3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent Intent_pic = new Intent();
                Intent_pic.setType("video/*, images/*");
                Intent_pic.setAction(Intent.ACTION_PICK);
                startActivityForResult(Intent_pic,0);
            }
        });
        getCamera3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int request_image_capture=1;
                Intent takephoto = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                if(takephoto.resolveActivity(getPackageManager())!= null){
                    startActivityForResult(takephoto,request_image_capture);
                }
            }
        });
    }
    @SuppressLint("LongLogTag")
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        try{
            switch(requestCode)
            {
                case 0:{
                    if(resultCode == Activity.RESULT_OK){
                        Uri choosenImage = data.getData();
                        //final InputStream imageStream = getContentResolver().openInputStream(choosenImage);
                        //final Bitmap selectedImage = BitmapFactory.decodeStream(imageStream);
                        bp = decodeUri(choosenImage,400);
                        imageView3.setImageBitmap(bp);
                        //Intent Intent_pic2 = new Intent(Intent.ACTION_VIEW, Uri.parse(selectedItem));
                        //startActivity(Intent_pic2);
                    }
                    else{
                        Log.d("Week7 onActivityResult ", "Selection Cancelled "+requestCode+ " " + resultCode);
                    } break;
                }
                case 1:{
                    if(resultCode == Activity.RESULT_OK){
                        Bundle extras = data.getExtras();
                        Bitmap imagebtm = (Bitmap)extras.get("data");
                        bp = imagebtm;
                        imageView3.setImageBitmap(imagebtm);


                        //show_image.setImageBitmap(destination);

                    }
                    else{
                        Log.d("Week7 onActivityResult ", "Selection Cancelled "+requestCode+ " " + resultCode);
                    } break;
                }
            }

        }
        catch(Exception e){
            Log.d("Week7 (onActivityResult)",e.getMessage());
        }

    }

    private Bitmap convertToBitmap3(byte[] b){

        return BitmapFactory.decodeByteArray(b, 0, b.length);

    }
    protected Bitmap decodeUri(Uri selectedImage1, int REQUIRED_SIZE) {

        try {

            // Decode image size
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeStream(getContentResolver().openInputStream(selectedImage1), null, o);

            // The new size we want to scale to
            // final int REQUIRED_SIZE =  size;

            // Find the correct scale value. It should be the power of 2.
            int width_tmp = o.outWidth, height_tmp = o.outHeight;
            int scale = 1;
            while (true) {
                if (width_tmp / 2 < REQUIRED_SIZE
                        || height_tmp / 2 < REQUIRED_SIZE) {
                    break;
                }
                width_tmp /= 2;
                height_tmp /= 2;
                scale *= 2;
            }

            // Decode with inSampleSize
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = scale;
            return BitmapFactory.decodeStream(getContentResolver().openInputStream(selectedImage1), null, o2);
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }
    private byte[] profileImage(Bitmap b){

        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        b.compress(Bitmap.CompressFormat.PNG, 0, bos);
        return bos.toByteArray();

    }
}
