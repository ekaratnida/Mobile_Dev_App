package com.example.pok.week7_0;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;

public class AddProfileActivity extends AppCompatActivity {
    EditText name_user,tel1,e_mail1;
    Button getphoto1,takephoto1,add_1;
    ImageView show_image;
    String filePath;
    byte[] photo ;
    Bitmap bp;
    Integer st1 ;
    //private static final String MY_PREFS = "my_detail";
    //private int status;
    private Contact contact3;
    private Integer _id3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_profile);
        final DatabaseHandler db = new DatabaseHandler(this);
       // getActionBar().setDisplayHomeAsUpEnabled(true);
        //SharedPreferences shared = getSharedPreferences(MY_PREFS,Context.MODE_PRIVATE);
        //final SharedPreferences.Editor editor = shared.edit();

        name_user = (EditText) findViewById(R.id.editTextName1);
        tel1 = (EditText) findViewById(R.id.editTextTel1);
        e_mail1 = (EditText) findViewById(R.id.editTextemail1);
        getphoto1 = (Button) findViewById(R.id.buttonGetphoto1);
        takephoto1 =(Button) findViewById(R.id.buttonTakePhoto1);
        add_1 = (Button) findViewById(R.id.buttonAdd1);
        show_image = (ImageView)  findViewById(R.id.imageView);
        //final Bundle bundle  = getIntent().getExtras();
        //   _id3 = bundle.getInt("id");
        //    contact3 = db.getContact(_id3.toString());
        //    if(bundle != null){
        //        name_user.setText(contact3._name);
        //        tel1.setText(contact3._phone_number);
        //        e_mail1.setText(contact3._e_mail);
        //       show_image.setImageBitmap(convertToBitmap2(contact3._img));
        //    }

        //final Integer final_id = _id3;
        add_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //if(bundle != null){
               // }else{
                //}
                //db.addContact(new Contact(name_user.getText().toString(),tel1.getText().toString(),e_mail1.getText().toString()));
                //Intent menuActivity =  new Intent(getApplicationContext(),MenuActivity.class);
                //startActivity(menuActivity);
                //finish();
                AlertDialog.Builder dialogAdd = new AlertDialog.Builder(AddProfileActivity.this);
                dialogAdd.setTitle("เพื่มรายชื่อ");
                dialogAdd.setMessage("คุณแน่ใจว่าจะเพิ่มรายชื่อหรือไม่");
                dialogAdd.setPositiveButton("ตกลง", new AlertDialog.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        photo = profileImage(bp);
                        db.addContact(new Contact(name_user.getText().toString(), tel1.getText().toString(), e_mail1.getText().toString(), photo));
                        finish();

                    }
                });
                dialogAdd.setNegativeButton("ยกเลิก", new AlertDialog.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.cancel();
                    }
                });
                dialogAdd.show();
            }
        });
        takephoto1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int request_image_capture=1;
                Intent takephoto = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                if(takephoto.resolveActivity(getPackageManager())!= null){
                    startActivityForResult(takephoto,request_image_capture);
                }
            }
        });
        getphoto1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent Intent_pic = new Intent();
                Intent_pic.setType("video/*, images/*");
                Intent_pic.setAction(Intent.ACTION_PICK);
                startActivityForResult(Intent_pic,0);
            }
        });
    }
    private Bitmap convertToBitmap2(byte[] b){

        return BitmapFactory.decodeByteArray(b, 0, b.length);

    }
    @SuppressLint("LongLogTag")
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        try{
            switch(requestCode)
            {
                case 0:{
                    if(resultCode == Activity.RESULT_OK){
                        Uri choosenImage = data.getData();
                        //final InputStream imageStream = getContentResolver().openInputStream(choosenImage);
                        //final Bitmap selectedImage = BitmapFactory.decodeStream(imageStream);
                        bp = decodeUri(choosenImage,400);
                        show_image.setImageBitmap(bp);
                        //Intent Intent_pic2 = new Intent(Intent.ACTION_VIEW, Uri.parse(selectedItem));
                        //startActivity(Intent_pic2);
                    }
                    else{
                        Log.d("Week7 onActivityResult ", "Selection Cancelled "+requestCode+ " " + resultCode);
                    } break;
                }
                case 1:{
                    if(resultCode == Activity.RESULT_OK){
                        Bundle extras = data.getExtras();
                        Bitmap imagebtm = (Bitmap)extras.get("data");
                        bp = imagebtm;
                        show_image.setImageBitmap(imagebtm);


                        //show_image.setImageBitmap(destination);

                    }
                    else{
                        Log.d("Week7 onActivityResult ", "Selection Cancelled "+requestCode+ " " + resultCode);
                    } break;
                }
            }

        }
        catch(Exception e){
            Log.d("Week7 (onActivityResult)",e.getMessage());
        }

    }
    private byte[] profileImage(Bitmap b){

        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        b.compress(Bitmap.CompressFormat.PNG, 0, bos);
        return bos.toByteArray();

    }
    protected Bitmap decodeUri(Uri selectedImage1, int REQUIRED_SIZE) {

        try {

            // Decode image size
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeStream(getContentResolver().openInputStream(selectedImage1), null, o);

            // The new size we want to scale to
            // final int REQUIRED_SIZE =  size;

            // Find the correct scale value. It should be the power of 2.
            int width_tmp = o.outWidth, height_tmp = o.outHeight;
            int scale = 1;
            while (true) {
                if (width_tmp / 2 < REQUIRED_SIZE
                        || height_tmp / 2 < REQUIRED_SIZE) {
                    break;
                }
                width_tmp /= 2;
                height_tmp /= 2;
                scale *= 2;
            }

            // Decode with inSampleSize
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = scale;
            return BitmapFactory.decodeStream(getContentResolver().openInputStream(selectedImage1), null, o2);
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }

}
