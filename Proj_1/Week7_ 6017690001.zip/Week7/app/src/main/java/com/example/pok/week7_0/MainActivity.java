package com.example.pok.week7_0;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final DatabaseHandler db = new DatabaseHandler(this);

        int numOfmembers = 5;
        for(int i=1; i<numOfmembers; i++) {
            //db.addContact(new Contact("Ekarat_"+i, "00"+i));
        }

        //db.deleteContact(new Contact("Bell","01111111111"));

        final List<Contact> contacts = db.getAllContacts();

        /*String[] datas = new String[contacts.size()];
        for(int i=0; i<datas.length; i++)
        {
            datas[i]= contacts.get(i)._name;
        }

        CustomAdapter adapter = new CustomAdapter(getApplicationContext(), datas);
        */
        final String[] menuDialog = getResources().getStringArray(R.array.menu1);
        final CustomAdapter adapter = new CustomAdapter(getApplicationContext(), contacts);
        ListView listView = (ListView)findViewById(R.id.listView1);
        listView.setAdapter(adapter);
        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view,final int i1, long l) {
                final Contact _contact = adapter._contacts.get(i1);
                final int _id = _contact._id;
                final String _name1 =_contact._name;

                AlertDialog.Builder dialog = new AlertDialog.Builder(MainActivity.this);
                final AlertDialog.Builder dialog1 = new AlertDialog.Builder(MainActivity.this);

                dialog.setTitle("โปรดเลือกการทำงาน");
                dialog.setItems(menuDialog, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i2) {
                        String selected = menuDialog[i2];

                        if(selected == menuDialog[0]){
                            Intent detailActivity =  new Intent(getApplicationContext(),DetailActivity.class);
                            detailActivity.putExtra("id1",_id);
                            detailActivity.putExtra("name",_name1);
                            startActivity(detailActivity);

                        }
                        else{
                            dialog1.setTitle("ลบข้อมูลที่เลือก");
                            dialog1.setMessage("คุณแน่ใจว่าจะลบข้อมูลนี้หรือไม่");
                            dialog1.setPositiveButton("ตกลง", new AlertDialog.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i3) {
                                    adapter._contacts.remove(i1);
                                    db.deleteContact(_contact);
                                    adapter.notifyDataSetChanged();
                                }
                            });
                            dialog1.setNegativeButton("ยกเลิก", new AlertDialog.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i4) {
                                    dialogInterface.cancel();
                                }
                            });
                            dialog1.show();
                        }

                    }
                });
                dialog.show();

                return false;
            }
        });
    }
}
