package com.example.pok.week7_0;

import android.graphics.Bitmap;

/**
 * Created by pok on 2/15/2017.
 */

public class Contact
{
    public int _id;
    public String _name;
    public String _phone_number;
    public String _e_mail;
    public byte[] _img;
    public Contact(){}
    public Contact(String name, String _phone_number,String _e_mail,byte[] _img) {
        //this._id = id;
        this._name = name;
        this._phone_number = _phone_number;
        this._e_mail = _e_mail;
        this._img = _img;
    }
    public Contact(int id, String name, String _phone_number,String _e_mail,byte[] _img) {
        this._id = id;
        this._name = name;
        this._phone_number = _phone_number;
        this._e_mail = _e_mail;
        this._img = _img;
    }
}