package com.example.pok.week7_0;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class DetailActivity extends AppCompatActivity {
    private TextView nameText,telText,e_mailText;
    private Button editButton,updateButton;
    private Contact contact1;
    private ImageView imgView;
    private String name2,tel2,e_mail2;
    private Integer status1;
    private byte[] photo2;
    //String Name2,Tel2,E_mail2;
    private static final String MY_PREFS1 = "my_prefs";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        final DatabaseHandler db1 = new DatabaseHandler(this);
        Bundle bundle  = getIntent().getExtras();
        //final String MY_PREFS1 = bundle.getString("MY_PREFS");
        SharedPreferences shared1 = getSharedPreferences(MY_PREFS1,
                Context.MODE_PRIVATE);
        final Integer _id1 = bundle.getInt("id1");

        //final  byte[] photo2 =getIntent().getByteArrayExtra("Img");
        //final  Integer status1 = bundle.getInt("Status");

        String _name = bundle.getString("name");
        nameText = (TextView) findViewById(R.id.textViewname_detail);
        telText = (TextView) findViewById(R.id.textViewtel_detail);
        e_mailText = (TextView) findViewById(R.id.textViewe_mail_detail);
        editButton =(Button) findViewById(R.id.buttonedit);
        updateButton= (Button) findViewById(R.id.buttonupdate);
        imgView = (ImageView) findViewById(R.id.imageDetail);

        contact1 = db1.getContact(_id1.toString());
        //Toast.makeText(getApplicationContext(), "คุณเลือก " +
        //        contact1._name, Toast.LENGTH_SHORT).show();
        //Toast.makeText(getApplicationContext(), "status1= "+ status1,Toast.LENGTH_SHORT).show();
        nameText.setText("Name: "+contact1._name);
        telText.setText("Tel: "+contact1._phone_number);
        e_mailText.setText("E_mail: "+contact1._e_mail);
        imgView.setImageBitmap(convertToBitmap1(contact1._img));
        editButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent editIntent = new Intent(DetailActivity.this,EditUpadateActivity.class);
                editIntent.putExtra("id",contact1._id);
                startActivity(editIntent);
                onDestroy();
            }
        });
        updateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder dialog2 = new AlertDialog.Builder(DetailActivity.this);
                dialog2.setTitle("DetailProfile");
                dialog2.setMessage("คุณยังไม่มีการแก้ไขข้อมูล กรุณากด Edit");
                dialog2.setPositiveButton("ตกลง", new AlertDialog.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i3) {
                        dialogInterface.cancel();
                    }
                });
                dialog2.show();
            }
        });


    }

    private Bitmap convertToBitmap1(byte[] b){

        return BitmapFactory.decodeByteArray(b, 0, b.length);

    }
}
